package com.pscodes.android

import android.app.Activity
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import org.json.JSONArray
import org.json.JSONObject

class MainActivity : ComponentActivity() {
    private val projectionLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        if (result.resultCode == Activity.RESULT_OK && result.data != null) {
            val service = Intent(this, CaptureService::class.java).apply {
                action = CaptureService.ACTION_START
                putExtra(CaptureService.EXTRA_RESULT_CODE, result.resultCode)
                putExtra(CaptureService.EXTRA_DATA, result.data)
            }
            ContextCompat.startForegroundService(this, service)
        }
    }
    private val records = mutableStateListOf<String>()
    private var status by mutableStateOf("Detenido")
    private var latest by mutableStateOf("—")

    private val events = object : BroadcastReceiver() {
        override fun onReceive(context: Context, intent: Intent) {
            when (intent.action) {
                CaptureService.EVENT_CODE -> {
                    val code = intent.getStringExtra(CaptureService.EXTRA_CODE) ?: return
                    latest = code
                    if (records.none { it.substringAfter(" · ").substringBefore(" · ") == code }) {
                        records.add(0, "${java.text.DateFormat.getTimeInstance().format(java.util.Date())} · $code · Revisar")
                        if (records.size > 100) records.removeAt(records.lastIndex)
                        saveHistory()
                    }
                    status = "Candidato detectado · revisa antes de canjear"
                }
                CaptureService.EVENT_STATE -> status = intent.getStringExtra(CaptureService.EXTRA_STATE) ?: status
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        loadHistory()
        val filter = IntentFilter().apply {
            addAction(CaptureService.EVENT_CODE)
            addAction(CaptureService.EVENT_STATE)
        }
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(events, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(events, filter)

        setContent {
            MaterialTheme {
                Surface(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                        Text("PS CODES ANDROID", style = MaterialTheme.typography.headlineSmall)
                        Text("Detector de pantalla · OCR local · canje manual supervisado")
                        ElevatedCard(Modifier.fillMaxWidth()) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Text("Estado", style = MaterialTheme.typography.labelLarge)
                                Text(status)
                                Text("Último candidato: $latest", style = MaterialTheme.typography.titleMedium)
                            }
                        }
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            Button(onClick = { requestCapture() }) { Text("Iniciar captura") }
                            OutlinedButton(onClick = {
                                startService(Intent(this@MainActivity, CaptureService::class.java).setAction(CaptureService.ACTION_STOP))
                                status = "Deteniendo…"
                            }) { Text("Detener") }
                        }
                        Text("Al iniciar, acepta el permiso de captura de Android y luego abre Twitch. El vídeo protegido puede aparecer negro.", style = MaterialTheme.typography.bodySmall)
                        HorizontalDivider()
                        Text("Historial de candidatos", style = MaterialTheme.typography.titleMedium)
                        if (records.isEmpty()) Text("Aún no se detectan códigos.")
                        LazyColumn(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(records) { item -> Text(item, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp)) }
                        }
                    }
                }
            }
        }
    }

    private fun requestCapture() {
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(manager.createScreenCaptureIntent())
        status = "Esperando permiso de captura de Android…"
    }

    private fun saveHistory() {
        val array = JSONArray()
        records.forEach(array::put)
        getSharedPreferences("pscodes", MODE_PRIVATE).edit().putString("history", array.toString()).apply()
    }

    private fun loadHistory() {
        runCatching {
            val array = JSONArray(getSharedPreferences("pscodes", MODE_PRIVATE).getString("history", "[]"))
            for (i in 0 until array.length()) records.add(array.getString(i))
            if (records.isNotEmpty()) latest = records.first().substringAfter(" · ").substringBefore(" · ")
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(events) }
        super.onDestroy()
    }
}
