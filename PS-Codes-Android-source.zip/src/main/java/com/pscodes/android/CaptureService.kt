package com.pscodes.android

import android.app.*
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.util.DisplayMetrics
import android.view.WindowManager
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.util.concurrent.atomic.AtomicBoolean

class CaptureService : Service() {
    companion object {
        const val ACTION_START = "com.pscodes.android.START"
        const val ACTION_STOP = "com.pscodes.android.STOP"
        const val EVENT_CODE = "com.pscodes.android.CODE"
        const val EVENT_STATE = "com.pscodes.android.STATE"
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_DATA = "projectionData"
        const val EXTRA_CODE = "code"
        const val EXTRA_STATE = "state"
        private const val CHANNEL = "capture"
        private const val NOTIFICATION = 41
    }

    private var projection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val busy = AtomicBoolean(false)
    private val seen = mutableSetOf<String>()
    private var lastFrameAt = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP -> stopCapture()
            ACTION_START -> startCapture(intent)
        }
        return START_NOT_STICKY
    }

    private fun startCapture(intent: Intent) {
        if (projection != null) return
        createChannel()
        startForeground(NOTIFICATION, notification("Capturando pantalla con permiso del usuario"))
        val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data = intent.getParcelableExtra<Intent>(EXTRA_DATA)
        if (resultCode != Activity.RESULT_OK || data == null) { stopCapture(); return }
        val manager = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = manager.getMediaProjection(resultCode, data)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, Handler(mainLooper))
        val metrics = DisplayMetrics()
        @Suppress("DEPRECATION")
        (getSystemService(WINDOW_SERVICE) as WindowManager).defaultDisplay.getRealMetrics(metrics)
        val density = metrics.densityDpi
        val width = metrics.widthPixels
        val height = metrics.heightPixels
        thread = HandlerThread("pscodes-ocr").also { it.start() }
        handler = Handler(thread!!.looper)
        reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        reader?.setOnImageAvailableListener({ source -> analyzeLatest(source) }, handler)
        virtualDisplay = projection?.createVirtualDisplay(
            "PS Codes capture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader?.surface, null, handler
        )
        broadcastState("Capturando · abre Twitch y deja visible el vídeo")
    }

    private fun analyzeLatest(source: ImageReader) {
        val now = System.currentTimeMillis()
        if (now - lastFrameAt < 900 || !busy.compareAndSet(false, true)) return
        lastFrameAt = now
        var image: Image? = null
        try {
            image = source.acquireLatestImage() ?: run { busy.set(false); return }
            val bitmap = imageToBitmap(image)
            image.close(); image = null
            recognizer.process(InputImage.fromBitmap(bitmap, 0))
                .addOnSuccessListener { text ->
                    val normalized = text.text.uppercase().replace(Regex("[‐‑–—]"), "-")
                    val pattern = Regex("(?<![A-Z0-9])[A-Z0-9]{4}(?:[- ]?[A-Z0-9]{4}){2}(?![A-Z0-9])")
                    pattern.findAll(normalized).forEach { match ->
                        val raw = match.value.replace(Regex("[^A-Z0-9]"), "")
                        if (seen.add(raw)) {
                            sendBroadcast(Intent(EVENT_CODE).setPackage(packageName).putExtra(EXTRA_CODE, raw.chunked(4).joinToString("-")))
                        }
                    }
                    if (text.text.isBlank()) broadcastState("Capturando · OCR no ve texto en el fotograma")
                }
                .addOnFailureListener { broadcastState("Error de OCR: ${it.localizedMessage ?: "desconocido"}") }
                .addOnCompleteListener { bitmap.recycle(); busy.set(false) }
        } catch (e: Exception) {
            image?.close()
            busy.set(false)
            broadcastState("Error de captura: ${e.localizedMessage ?: e.javaClass.simpleName}")
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * image.width
        val padded = Bitmap.createBitmap(image.width + rowPadding / pixelStride, image.height, Bitmap.Config.ARGB_8888)
        padded.copyPixelsFromBuffer(plane.buffer)
        val crop = Bitmap.createBitmap(padded, 0, 0, image.width, image.height)
        padded.recycle()
        return crop
    }

    private fun stopCapture() {
        virtualDisplay?.release(); virtualDisplay = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        thread?.quitSafely(); thread = null; handler = null
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
        broadcastState("Detenido")
    }

    private fun broadcastState(state: String) = sendBroadcast(Intent(EVENT_STATE).setPackage(packageName).putExtra(EXTRA_STATE, state))

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(NotificationChannel(CHANNEL, "Captura PS Codes", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun notification(message: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_menu_view)
        .setContentTitle("PS Codes Android")
        .setContentText(message)
        .setOngoing(true)
        .build()
}
