# PS Codes Android

Android proof of concept for user-consented screen capture, on-device OCR, code validation, deduplication and a persisted detection history.

This build deliberately stops before submitting a redemption. PlayStation UI automation requires device-level validation against the installed PlayStation App and is not enabled by default.

## Build

Open this directory in Android Studio (JDK 17) and sync the Gradle project. The first build needs network access to resolve Android Gradle Plugin and ML Kit. Install the resulting debug APK on the Galaxy S23 Ultra and grant screen capture when prompted.

## Current limits

- Android MediaProjection captures the current display after explicit user consent; protected video can appear black.
- OCR runs on-device using ML Kit. Detection is heuristic and shows candidates for review.
- No passwords or PlayStation credentials are collected or stored.
- Code is not submitted automatically. Accessibility based redemption is a separate, device-validated phase.
